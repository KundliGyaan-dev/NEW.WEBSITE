import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

interface FAQItem {
  question: string;
  answer: string;
}

const faqs: FAQItem[] = [
  {
    question: "What is a birth chart reading?",
    answer: "A birth chart (also called natal chart) is a map of the sky at the exact moment of your birth. It reveals the precise position of each planet and how they influence different aspects of your life, including personality traits, relationships, career, and more."
  },
  {
    question: "How accurate are online astrology consultations?",
    answer: "Online consultations are just as accurate as in-person ones. Our expert astrologers use the same precise calculations and ancient wisdom to analyze your chart, providing detailed insights regardless of the consultation method."
  },
  {
    question: "What information do I need for a consultation?",
    answer: "For an accurate reading, you'll need your date of birth, exact time of birth, and place of birth. These details help create your precise birth chart and ensure accurate predictions."
  },
  {
    question: "How long does a typical consultation last?",
    answer: "Our standard consultations typically last 30-60 minutes, depending on the type of reading and depth of analysis you choose. We also offer mini-sessions and comprehensive extended readings."
  },
  {
    question: "Can astrology help with career decisions?",
    answer: "Yes, astrology can provide valuable insights into your natural talents, favorable career paths, and optimal timing for career moves by analyzing your birth chart's career houses and planetary positions."
  }
];

const FAQ: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div id="faq" className="py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-white mb-4">Frequently Asked Questions</h2>
          <p className="text-purple-200">Find answers to common questions about our astrology services</p>
        </div>
        <div className="space-y-4 max-w-3xl mx-auto">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="bg-white/10 backdrop-blur-lg rounded-xl border border-white/20 overflow-hidden"
            >
              <button
                className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-white/5 transition-all duration-200"
                onClick={() => toggleFAQ(index)}
              >
                <span className="text-lg font-medium text-white">{faq.question}</span>
                {openIndex === index ? (
                  <ChevronUp className="h-5 w-5 text-purple-300" />
                ) : (
                  <ChevronDown className="h-5 w-5 text-purple-300" />
                )}
              </button>
              <div
                className={`px-6 transition-all duration-200 ease-in-out ${
                  openIndex === index ? 'py-4' : 'py-0 h-0'
                } overflow-hidden`}
              >
                <p className="text-purple-200">{faq.answer}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default FAQ;