import React from 'react';

const BirthChart = () => {
  // Sample data for Birth Chart (Houses, Planets, Signs, etc.)
  const birthChartData = {
    lagna: "Taurus",
    houses: [
      { house: 1, sign: "Aries" },
      { house: 2, sign: "Taurus" },
      { house: 3, sign: "Gemini" },
      { house: 4, sign: "Cancer" },
      { house: 5, sign: "Leo" },
      { house: 6, sign: "Virgo" },
      { house: 7, sign: "Libra" },
      { house: 8, sign: "Scorpio" },
      { house: 9, sign: "Sagittarius" },
      { house: 10, sign: "Capricorn" },
      { house: 11, sign: "Aquarius" },
      { house: 12, sign: "Pisces" }
    ],
    planets: [
      { name: "Sun", position: 0, sign: "Aries" },
      { name: "Moon", position: 30, sign: "Taurus" },
      { name: "Mercury", position: 60, sign: "Gemini" },
      { name: "Venus", position: 90, sign: "Cancer" },
      { name: "Mars", position: 120, sign: "Leo" },
    ],
  };

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
      <h3 className="text-xl font-semibold text-white mb-4">Birth Chart</h3>
      <div className="aspect-square relative">
        <div className="absolute inset-0 border-2 border-purple-300/30 rounded-lg transform rotate-45">
          <div className="absolute inset-4 border-2 border-purple-300/30"></div>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-white text-center">
              <div className="text-sm font-medium">Lagna</div>
              <div className="text-xs text-purple-200">{birthChartData.lagna}</div>
            </div>
          </div>
          {/* Chart divisions */}
          <div className="absolute inset-0">
            <div className="absolute top-0 left-1/2 h-full w-0.5 bg-purple-300/30 transform -translate-x-1/2"></div>
            <div className="absolute top-1/2 left-0 w-full h-0.5 bg-purple-300/30 transform -translate-y-1/2"></div>
          </div>

          {/* Dynamic Rendering of Houses */}
          {birthChartData.houses.map((house, index) => {
            const rotationAngle = (index * 30) + 45; // 30 degrees per house, plus 45 for initial rotation
            return (
              <div
                key={house.house}
                className="absolute inset-0 flex items-center justify-center"
                style={{
                  transform: `rotate(${rotationAngle}deg)`,
                  top: "50%",
                  left: "50%",
                  position: "absolute",
                }}
              >
                <div className="text-white text-center">
                  <div className="text-xs">{house.house}</div>
                  <div className="text-xs text-purple-200">{house.sign}</div>
                </div>
              </div>
            );
          })}

          {/* Dynamic Rendering of Planets */}
          {birthChartData.planets.map((planet, index) => {
            const rotationAngle = planet.position; // Simulate the planet position on the wheel
            return (
              <div
                key={planet.name}
                className="absolute inset-0 flex items-center justify-center"
                style={{
                  transform: `rotate(${rotationAngle}deg)`,
                  top: "50%",
                  left: "50%",
                  position: "absolute",
                }}
              >
                <div className="text-white text-center">
                  <div className="text-xs">{planet.name}</div>
                  <div className="text-xs text-purple-200">{planet.sign}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default BirthChart;
