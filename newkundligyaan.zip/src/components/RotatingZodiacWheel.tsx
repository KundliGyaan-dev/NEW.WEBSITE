import React, { useEffect, useRef } from 'react';

const RotatingZodiacWheel: React.FC = () => {
  const wheelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.scrollY;
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      const scrollPercent = (scrollTop / docHeight) * 100;
      const rotation = scrollPercent * 3.6; // 360 degrees / 100 = 3.6 degrees per scroll percent

      if (wheelRef.current) {
        wheelRef.current.style.transform = `rotate(${rotation}deg)`;
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="fixed right-[-300px]  top-1/2 -translate-y-1/2 pointer-events-none z-50 overflow-hidden">
      <div
        ref={wheelRef}
        className="w-[600px] h-[600px] transform-gpu"
      >
        <img 
          src="wheel.png" 
          alt="Zodiac Wheel" 
          className="w-[600px] h-300px object-contain opacity-30 hover:opacity-50 transition-opacity"
        />
      </div>
    </div>
  );
};

export default RotatingZodiacWheel;
