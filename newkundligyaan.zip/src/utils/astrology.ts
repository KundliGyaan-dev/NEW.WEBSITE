export const calculateMoonSign = (date: string, time: string): string => {
  // This is a placeholder function that would normally contain complex
  // calculations based on astronomical algorithms
  return "Taurus";
};

export const zodiacSigns = [
  "Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo",
  "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces"
];