import React from 'react';
import { Stars, Heart, Users, Clock, Award } from 'lucide-react';
import FAQ from './components/FAQ';
import RotatingZodiacWheel from './components/RotatingZodiacWheel';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import BirthChart from './components/BirthChart.tsx';

function App() {
  return (
    <Router>  {/* Wrap the entire app in Router for routing */}
      <div className="min-h-screen bg-gradient-to-b from-indigo-950 via-purple-900 to-indigo-950">
        <RotatingZodiacWheel />
        
        {/* Navigation */}
   <nav className="fixed w-full z-50 bg-white border-b border-gray-200">
  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
    <div className="flex items-center justify-start">
      {/* Logo and Text aligned to the left */}
      <div className="flex items-center space-x-2">
        <img 
          src="wheel.png" 
          alt="Kundli Gyaan Logo" 
          className="h-8 w-8 object-contain"
        />
        <span className="text-2xl font-bold text-gray-800">
          Kundli Gyaan
        </span>
      </div>

      {/* Middle-aligned elements (e.g., navigation links) */}
      <div className="hidden md:flex space-x-8 justify-center flex-grow">
        <a href="#features" className="text-gray-800 hover:text-orange-500 transition">Features</a>
        <a href="#testimonials" className="text-gray-800 hover:text-orange-500 transition">Testimonials</a>
        <a href="#faq" className="text-gray-800 hover:text-orange-500 transition">FAQ</a>
        <a href="#contact" className="text-gray-800 hover:text-orange-500 transition">Contact</a>
      </div>

      {/* Right-side content (e.g., buttons) */}
      <div>
        <button className="bg-gradient-to-r from-orange-500 to-orange-600 text-white px-6 py-2 rounded-lg">
          Get Started
        </button>
      </div>
    </div>
  </div>
</nav>


        {/* Hero Section */}
        <div className="pt-24 pb-16 md:pt-32 md:pb-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
                Discover Your Cosmic Path with
                <span className="block bg-gradient-to-r from-yellow-200 to-yellow-500 text-transparent bg-clip-text">
                  Expert Astrologers
                </span>
              </h1>
              <p className="text-xl text-purple-200 mb-8 max-w-2xl mx-auto">
                Get personalized astrological guidance from India's leading astrologers. 
                Unlock the secrets of your birth chart and navigate life's journey with confidence.
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <button className="bg-gradient-to-r from-purple-500 to-indigo-600 text-white px-8 py-4 rounded-lg font-semibold hover:from-purple-600 hover:to-indigo-700 transition-all duration-300 shadow-lg">
                  Chat with Astrologer
                </button>
                <button className="bg-white/10 backdrop-blur-md text-white px-8 py-4 rounded-lg font-semibold hover:bg-white/20 transition-all duration-300 border border-white/20">
                  Book a Session
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Features */}
        <div id="features" className="py-16 bg-black/20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-white mb-4">Why Choose Us</h2>
              <p className="text-purple-200">Experience the difference with our expert astrologers</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                {
                  icon: <Users className="h-8 w-8 text-yellow-300" />,
                  title: "Expert Astrologers",
                  description: "Verified and experienced astrologers from across India"
                },
                {
                  icon: <Clock className="h-8 w-8 text-yellow-300" />,
                  title: "24/7 Availability",
                  description: "Get instant guidance whenever you need it"
                },
                {
                  icon: <Award className="h-8 w-8 text-yellow-300" />,
                  title: "100% Privacy",
                  description: "Your personal information is always protected"
                }
              ].map((feature, index) => (
                <div key={index} className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20 hover:bg-white/20 transition-all duration-300">
                  <div className="flex flex-col items-center text-center">
                    {feature.icon}
                    <h3 className="text-xl font-semibold text-white mt-4 mb-2">{feature.title}</h3>
                    <p className="text-purple-200">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Testimonials */}
        <div id="testimonials" className="py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-white mb-4">What Our Clients Say</h2>
              <p className="text-purple-200">Join thousands of satisfied customers</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                {
                  name: "Priya Sharma",
                  role: "Entrepreneur",
                  content: "The guidance I received was incredibly accurate and helped me make important business decisions."
                },
                {
                  name: "Rahul Verma",
                  role: "Software Engineer",
                  content: "I was skeptical at first, but the detailed birth chart analysis was eye-opening."
                },
                {
                  name: "Anita Patel",
                  role: "Doctor",
                  content: "The remedies suggested helped me overcome several challenges in my career."
                }
              ].map((testimonial, index) => (
                <div key={index} className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
                  <div className="flex flex-col h-full">
                    <div className="flex-grow">
                      <Heart className="h-6 w-6 text-yellow-300 mb-4" />
                      <p className="text-purple-200 mb-4">{testimonial.content}</p>
                    </div>
                    <div>
                      <p className="font-semibold text-white">{testimonial.name}</p>
                      <p className="text-sm text-purple-200">{testimonial.role}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="py-16 bg-black/20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="bg-gradient-to-r from-purple-900 to-indigo-900 rounded-2xl p-8 md:p-12 border border-white/20 backdrop-blur-lg">
              <div className="text-center">
                <h2 className="text-3xl font-bold text-white mb-4">Begin Your Spiritual Journey Today</h2>
                <p className="text-xl text-purple-200 mb-8 max-w-2xl mx-auto">
                  Get your first consultation at a special introductory price
                </p>
                <button className="bg-gradient-to-r from-yellow-400 to-yellow-600 text-black px-8 py-4 rounded-lg font-semibold hover:from-yellow-500 hover:to-yellow-700 transition-all duration-300 shadow-lg">
                  Start Now
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* FAQ Section */}
        <FAQ />

        {/* Footer */}
        <footer className="py-8 border-t border-white/10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <div className="flex items-center space-x-2 mb-4 md:mb-0">
                <Stars className="h-6 w-6 text-yellow-300" />
                <span className="text-xl font-bold text-white">Kundli Gyaan</span>
              </div>
              <div className="flex space-x-6">
                <a href="#" className="text-purple-200 hover:text-white transition">Privacy Policy</a>
                <a href="#" className="text-purple-200 hover:text-white transition">Terms of Service</a>
                <a href="#" className="text-purple-200 hover:text-white transition">Contact</a>
              </div>
            </div>
          </div>
        </footer>
        
        {/* Routes */}
        <Routes>
          <Route path="/birthchart" element={<BirthChart />} />  {/* Define route for BirthChart */}
          {/* Add other routes here */}
        </Routes>
      </div>
    </Router>
  );
}

export default App;
